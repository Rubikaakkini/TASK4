/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to compress using Run-Length Encoding (RLE)
void compressFile(const char *inputFile, const char *outputFile) {
    FILE *in = fopen(inputFile, "r");
    FILE *out = fopen(outputFile, "w");

    if (!in || !out) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char current, previous;
    int count = 1;

    // Read the first character
    previous = fgetc(in);

    while ((current = fgetc(in)) != EOF) {
        if (current == previous) {
            count++;
        } else {
            fprintf(out, "%c%d", previous, count);
            previous = current;
            count = 1;
        }
    }

    // Write the last character and its count
    if (previous != EOF) {
        fprintf(out, "%c%d", previous, count);
    }

    fclose(in);
    fclose(out);

    printf("File compressed successfully to %s.\n", outputFile);
}

// Function to decompress a file compressed using RLE
void decompressFile(const char *inputFile, const char *outputFile) {
    FILE *in = fopen(inputFile, "r");
    FILE *out = fopen(outputFile, "w");

    if (!in || !out) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char ch;
    int count;

    while (fscanf(in, "%c%d", &ch, &count) == 2) {
        for (int i = 0; i < count; i++) {
            fputc(ch, out);
        }
    }

    fclose(in);
    fclose(out);

    printf("File decompressed successfully to %s.\n", outputFile);
}

int main() {
    int choice;
    char inputFile[100], outputFile[100];

    while (1) {
        printf("\nRun-Length Encoding Compression Tool\n");
        printf("1. Compress File\n");
        printf("2. Decompress File\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the name of the input file to compress: ");
                scanf("%s", inputFile);
                printf("Enter the name of the output compressed file: ");
                scanf("%s", outputFile);
                compressFile(inputFile, outputFile);
                break;
            case 2:
                printf("Enter the name of the compressed file to decompress: ");
                scanf("%s", inputFile);
                printf("Enter the name of the output decompressed file: ");
                scanf("%s", outputFile);
                decompressFile(inputFile, outputFile);
                break;
            case 3:
                printf("Exiting program.\n");
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
